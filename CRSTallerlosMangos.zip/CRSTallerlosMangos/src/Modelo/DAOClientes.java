package Modelo;
import java.util.*;
import javax.swing.table.DefaultTableModel;


/*** @author TallerlosMangos
 */
public class DAOClientes {
    
    
    public Clientes Insertar(String nombres, String apellidos, String tipo_cliente,
            String telefono, String cedula, String municipio, String sexo ) {
     String transaccion ="INSERT INTO Clientes (nombres,apellidos,tipo_cliente,"
        + "telefono,cedula,municipio,sexo) VALUES ('"
                + nombres + "', '" 
                + apellidos + "', '"
                + tipo_cliente + "', '"
                + telefono + "', '"
                + cedula + "', '"
                + municipio + "', '"
                + sexo + "')";
        
        if (new DataBase().Actualizar(transaccion)>0){
                return new Clientes(nombres, apellidos, tipo_cliente,
                        telefono, cedula , municipio, sexo);
                }
        return null;                
        }   
//Este es el codigo de buscar, tienes que cambiar la consulta de select segun los datos que hay en la bd, tienen que estar identicos
  public List<Clientes> buscar(String termino) {
    String transaccion = "SELECT * FROM Clientes WHERE " +
            "nombres LIKE '%" + termino + "%' OR " +
            "apellidos LIKE '%" + termino + "%' OR " +
            "tipo_cliente LIKE '%" + termino + "%' OR " +
            "telefono LIKE '%" + termino + "%' OR " +
            "cedula LIKE '%" + termino + "%' OR " +
            "municipio LIKE '%" + termino + "%' OR " +
            "sexo LIKE '%" + termino + "%'";

    List<Map> registros = new DataBase().Listar(transaccion);
    List<Clientes> clientes = new ArrayList<>();

    for (Map registro : registros) {
        int id_cliente = registro.get("id_cliente") != null ? (int)
                registro.get("id_cliente") : 0;
        String nombres = registro.get("nombres") != null ? (String)
                registro.get("nombres") : "";
        String apellidos = registro.get("apellidos") != null ? (String)
                registro.get("apellidos") : "";
        String tipoCliente = registro.get("tipo_cliente") != null ? (String) 
                registro.get("tipo_cliente") : "";
        String telefono = registro.get("telefono") != null ? (String) 
                registro.get("telefono") : "";
        String cedula = registro.get("cedula") != null ? (String) 
                registro.get("cedula") : "";
        String municipio = registro.get("municipio") != null ? (String)
                registro.get("municipio") : "";
        String sexo = registro.get("sexo") != null ? (String) 
                registro.get("sexo") : "";

Clientes cliente = new Clientes(id_cliente, nombres, apellidos, tipoCliente,
        telefono, cedula, municipio, sexo);

        clientes.add(cliente);
    }

    return clientes;
}

public int Actualizar(int id,String nombres,String apellidos,String tipo_cliente,
            String telefono,String cedula,String municipio,String sexo ) {
        String transaccion ="UPDATE Clientes SET nombres='"
                + nombres + "', apellidos='"
                + apellidos + "', tipo_cliente='"
                + tipo_cliente + "', telefono='"
                + telefono + "', cedula='"
                + cedula + "', municipio='"
                + municipio + "', sexo='"
                + sexo + "' WHERE id_cliente="
                + id ;       
        
        return new DataBase().Actualizar(transaccion);
    }
public List obtenerDatos() {
        String transaccion = "select * from clientes";
        List<Map> registros = new DataBase().Listar(transaccion);
        List<Clientes> cliente = new ArrayList();
        for (Map registro : registros){
            Clientes cli = new Clientes ((int) registro.get("id_cliente"),
            (String) registro.get("nombres"),
            (String) registro.get("apellidos"),
            (String) registro.get("tipo_cliente"), 
            (String) registro.get("telefono"),  
            (String) registro.get("cedula"),
            (String) registro.get("municipio"),
            (String) registro.get("sexo"));
        cliente.add(cli);    
        }
    return cliente;
    }
public int Eliminar(int id) {
        String transaccion = "delete from clientes where id_cliente='"+ id +"'";
        return new DataBase().Actualizar(transaccion);
    }
}
              