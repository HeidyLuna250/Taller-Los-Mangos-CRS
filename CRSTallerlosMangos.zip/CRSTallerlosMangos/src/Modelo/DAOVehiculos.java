package Modelo;
import java.util.*;

/*** @author TallerlosMangos
 */
public class DAOVehiculos {
    public Vehiculos Insertar(String n_placa, String color, String marca, Integer id_cliente) {
String transaccion ="INSERT INTO Vehiculos(n_placa,color,marca,id_cliente) VALUES ('"
                + n_placa + "', '" 
                + color + "', '"
                + marca + "', '"
                + id_cliente + "')";
        
        if (new DataBase().Actualizar(transaccion)>0){
                return new Vehiculos(n_placa, color, marca, id_cliente);
                }
        return null; 
    }
    
//Este es el codigo de buscar, tienes que cambiar la consulta de select segun los datos que hay en la bd, tienen que estar identicos
  public List<Vehiculos> buscar(String termino) {
    String transaccion = "SELECT * FROM vehiculos WHERE " +
            "n_placa LIKE '%" + termino + "%' OR " +
            "color LIKE '%" + termino + "%' OR " +
            "marca LIKE '%" + termino + "%' OR " +
            "id_cliente LIKE '%" + termino + "%'";

    List<Map> registros = new DataBase().Listar(transaccion);
    List<Vehiculos> vehiculos = new ArrayList<>();

    for (Map registro : registros) {
        int id_vehiculo = registro.get("id_vehiculo") != null ? (int)
                registro.get("id_vehiculo") : 0;
        String n_placa = registro.get("n_placa") != null ? (String)
                registro.get("n_placa") : "";
        String color = registro.get("color") != null ? (String)
                registro.get("color") : "";
        String marca = registro.get("marca") != null ? (String) 
                registro.get("marca") : "";
        String id_cliente = registro.get("id_cliente") != null ? (String) 
                registro.get("id_cliente") : "";

Vehiculos vehiculo = new Vehiculos(n_placa, color, marca, id_vehiculo);
        vehiculos.add(vehiculo);
    }

    return vehiculos;
}    

public int Actualizar(int id,String n_placa,String color,String marca,Integer id_cliente ) {
        String transaccion ="UPDATE Vehiculos SET nombres='"
                + n_placa + "', color='"
                + color + "', Marca= '"
                + marca + "', id_cliente='"
                + id_cliente + "', WHERE id_vehiculo="
                + id ;       
        
        return new DataBase().Actualizar(transaccion);
    }
public List obtenerDatos() {
        String transaccion = "select * from vehiculos";
        List<Map> registros = new DataBase().Listar(transaccion);
        List<Vehiculos> vehiculo = new ArrayList();
        for (Map registro : registros){
            Vehiculos veh = new Vehiculos ((int) registro.get("id_vehiculo"),
            (String) registro.get("n_placa"),
            (String) registro.get("color"),
            (String) registro.get("marca"),
            (Integer) registro.get("id_cliente"));
        vehiculo.add(veh);    
        }
    return vehiculo;
    }
public int Eliminar(int id) {
        String transaccion = "delete from vehiculos where id_vehiculo='"+ id +"'";
        return new DataBase().Actualizar(transaccion);
    }
}